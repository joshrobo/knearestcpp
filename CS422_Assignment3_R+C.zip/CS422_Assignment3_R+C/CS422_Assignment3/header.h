//console operations
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <set>
//file operations
#include <fstream>
//#include "readTestAndTrainingSet.h"
//file code

//for parsing csv
#include <sstream>

//classification code
//#include "k_nearest_neighbors.h"
//include knn algorithm file

//#include "euclidean_distance.h"
//#include "cosine_similarity.h"
//#include "pearson_correlation.h"
//distance measure files

using namespace std;
#include "distanceMeasures.h"
#include "knnClassifier.h"
using namespace knn422;